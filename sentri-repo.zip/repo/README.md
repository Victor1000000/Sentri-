# Sentri

One hidden action sends your live location to people you trust.

- `backend/` Node/TypeScript API (see `backend/README.md`)
- `mobile/` Flutter app (see `mobile/SETUP.md`)
- `docs/` security, deployment and legal notes
- `.github/workflows/build-apk.yml` builds the Android APK (Actions > Build Sentri APK > Run workflow)
